**********************************   README FILE   ***************************************

Contact: Savage Electronics - Electronics For Everyone
  Autor:  Josue Alejandro Savage
  E-mail: Josue.Gutierrez@savageelectronics.com 
  Web:    https://www.savageelectrtonics.com

Version: Dynamixel Library 0.4.2 GPL v2.1

Requeriments:

Arduino IDE Version 1.0 o superior
Wiring IDE 0100 o superior

Installation:

Copy the files to your IDE libraries folder.

examples:

In the Program:
Copy "Dynamixel" folder to Arduino/Contents/Resources/Java/libraries. 

or

In the SketchBook:
Copy "Dynamixel" folder to Arduino/libraries.

License:

 Dynamixel Half Duplex USART Comunication
 Copyright (c) 2011 Savage Electronics.
 Created by Josue Alejandro Gutierrez on 27/01/11.
 
 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 
 This library is distributed in the hope that it will be useful,  
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

******************************************************************************************
